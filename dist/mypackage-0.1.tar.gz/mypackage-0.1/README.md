# mypackage
This library was created as an example of how to publish your own Python packages

## building this package locally
`python setup.py sdict`

## installing this package from GitHub
`pip install git+https://github.com/Sindisiwe-Sambo/example-python-package.git`

## updating this package from GitHub
`pip install --upgrade git+https://github.com/Sindisiwe-Sambo/example-python-package.git `
